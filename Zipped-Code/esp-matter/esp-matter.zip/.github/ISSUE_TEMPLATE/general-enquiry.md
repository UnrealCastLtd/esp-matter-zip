---
name: General Enquiry
about: Questions related to Matter implementation, documentation, specification
title: ''
labels: ''
assignees: ''

---

**Describe the question/query that you have**
A clear and concise description of what you want to ask.

**Additional context**
...
