# zap_common

The files here are generic version of the files in zap-generated in the examples.

If there are errors and there is something missing in these files, it should be added in the files so that they
are generic again.
