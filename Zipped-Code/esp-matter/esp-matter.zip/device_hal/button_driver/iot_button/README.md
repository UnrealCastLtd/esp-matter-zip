# Source

The `button` component which is used for gpio and adc buttons is taken from https://github.com/espressif/esp-iot-solution/tree/master/components/button via idf_component.yml
