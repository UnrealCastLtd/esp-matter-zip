Client
=======

This has the APIs for Clients such as connect() and send_command().

API reference
-------------

.. include-build-file:: inc/esp_matter_client.inc
