Data Model
==========

This has the high level APIs for Data Model.

API reference
-------------

.. include-build-file:: inc/esp_matter_data_model.inc
