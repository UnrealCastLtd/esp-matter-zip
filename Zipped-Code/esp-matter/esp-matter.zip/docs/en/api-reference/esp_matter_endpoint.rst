Endpoint/Device Type
====================

This has the high level APIs for Endpoint/Device Type.

API reference
-------------

.. include-build-file:: inc/esp_matter_endpoint.inc
