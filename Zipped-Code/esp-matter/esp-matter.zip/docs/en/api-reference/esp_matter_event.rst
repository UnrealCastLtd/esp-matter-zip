Event
=======

This has the APIs for Events.

API reference
-------------

.. include-build-file:: inc/esp_matter_event.inc
