7. API Reference
================

.. toctree::
   :maxdepth: 1

   esp_matter_data_model.rst
   esp_matter_endpoint.rst
   esp_matter_cluster.rst
   esp_matter_attribute.rst
   esp_matter_command.rst
   esp_matter_core.rst
   esp_matter_event.rst
   esp_matter_client.rst
