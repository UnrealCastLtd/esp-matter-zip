# Managed Component Light

This example creates a Color Temperature Light device using the esp_matter component downloaded from [Espressif Component Registry](https://components.espressif.com/) instead of the extra component in local, so the example can work without setting the esp-matter environment.

See the [docs](https://docs.espressif.com/projects/esp-matter/en/latest/esp32/developing.html) for more information about building and flashing the firmware.
