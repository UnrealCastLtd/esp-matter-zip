### Commission the sample application

Your device is now flashed with sample firmware, please scan the below QR Code from any of the Matter supported phone
apps to setup the device. You can also use the manual setup codes.

<img src="https://raw.githubusercontent.com/espressif/esp-matter/main/docs/_static/matter_qrcode_20202021_3840.png" alt="MT:Y.K9042C00KA0648G00" width="30%" />

```
Manual Pairing Code: 34970112332
QRCode: MT:Y.K9042C00KA0648G00
```
