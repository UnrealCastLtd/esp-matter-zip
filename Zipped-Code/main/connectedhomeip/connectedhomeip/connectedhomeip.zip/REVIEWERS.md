People from the following groups can be chosen as, and act as required reviewers
on any PR

| Group                                                                             | Company              |
| --------------------------------------------------------------------------------- | -------------------- |
| [reviewers-apple](https://github.com/orgs/project-chip/teams/reviewers-apple)     | Apple, Inc.          |
| [reviewers-comcast](https://github.com/orgs/project-chip/teams/reviewers-comcast) | Comcast, Inc.        |
| [reviewers-google](https://github.com/orgs/project-chip/teams/reviewers-google)   | Google, Inc.         |
| [reviewers-nordic](https://github.com/orgs/project-chip/teams/reviewers-nordic)   | Nordic Semiconductor |
| [reviewers-samsung](https://github.com/orgs/project-chip/teams/reviewers-samsung) | Samsung SmartThings  |
| [reviewers-silabs](https://github.com/orgs/project-chip/teams/reviewers-silabs)   | Silicon Labs         |
