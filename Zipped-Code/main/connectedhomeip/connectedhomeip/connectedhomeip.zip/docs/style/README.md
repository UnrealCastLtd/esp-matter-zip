# Style

When necessary to drive into more detail about styles about specific types of
files this is where CHIP collects them

## Specific Types

-   [Makefiles](./STYLE_MAKEFILES.md)
