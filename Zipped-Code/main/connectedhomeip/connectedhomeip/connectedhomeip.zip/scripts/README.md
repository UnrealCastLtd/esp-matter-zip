# Scripts

Herein is a smattering of scripts, mostly bash, that:

-   capture repetitive developer workflow
-   provide glue for integration with CI and IDEs
-   provide tree build facilities (e.g. gen-chip-version.sh)
-   replicate tree-wide CI flows for local verification (e.g. helpers/)
