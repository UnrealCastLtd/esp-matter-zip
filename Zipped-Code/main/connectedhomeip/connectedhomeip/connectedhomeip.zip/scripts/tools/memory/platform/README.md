A config file is a Python (nested) dictionary used by
`memdf.util.config.Config`.

A config file given by a `--config-file` command line argument takes effect
_after_ built-in ConfigDescription defaults and _before_ any other command line
arguments.
