# Application layer for CHIP

## What is this?

The purpose of this folder is to contain CHIP clusters and associated utilities.
The cluster implementations live under the clusters/ directory. Utility files
live in the util/. Server files live in the server/.
