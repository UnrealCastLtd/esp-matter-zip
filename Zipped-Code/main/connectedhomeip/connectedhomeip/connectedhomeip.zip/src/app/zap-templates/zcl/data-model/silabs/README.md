# ZCL Meta Repository

This repository contains the test meta-files that describe the ZCL application
layer.

**IMPORTANT**: these files are NOT the root repository of the ZCL XML files. It
is ONLY a test snapshot so that the zap application has ability to run in a
standalone mode.

## License

The contents of this repository are licensed using the
[Apache 2.0 license](LICENSE.txt)
