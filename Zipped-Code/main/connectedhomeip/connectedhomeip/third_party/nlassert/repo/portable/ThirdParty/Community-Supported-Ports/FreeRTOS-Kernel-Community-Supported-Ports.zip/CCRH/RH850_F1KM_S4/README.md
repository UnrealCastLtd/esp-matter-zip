OVERVIEW

This directory contains FreeRTOS port for Renesas RH850 F1KM-S4

The standard demo project to test this port is added at following location: 
FreeRTOS-Community-Supported-Demos\RH850_F1KM_S4_CCRH

This port is distributed under MIT open source license. 

TOOL CHAIN SUPPORT: 
IDE and Coding Tool: e² studio version 07-2023
C Compiler Package for RH850 Family [CC-RH] version 2.06.00 for e2 studio.
FreeRTOS Kernel V11.0.1