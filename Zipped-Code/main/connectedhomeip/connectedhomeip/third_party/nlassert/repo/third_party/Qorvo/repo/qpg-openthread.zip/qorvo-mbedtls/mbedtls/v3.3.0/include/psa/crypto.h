

#if defined(PSA_CRYPTO_IMPLEMENTED)
#include "crypto_se.h"
#else
// #ifdef __cplusplus
// extern "C" {
// #endif
#include "crypto_mbedtls.h"
// #ifdef __cplusplus
// }
// #endif

#endif
