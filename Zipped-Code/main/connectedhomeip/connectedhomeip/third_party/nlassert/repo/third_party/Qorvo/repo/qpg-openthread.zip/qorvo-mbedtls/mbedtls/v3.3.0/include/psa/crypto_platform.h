#if defined(PSA_CRYPTO_IMPLEMENTED)
#include "crypto_platform_se.h"
#else
#include "crypto_platform_mbedtls.h"
#endif
