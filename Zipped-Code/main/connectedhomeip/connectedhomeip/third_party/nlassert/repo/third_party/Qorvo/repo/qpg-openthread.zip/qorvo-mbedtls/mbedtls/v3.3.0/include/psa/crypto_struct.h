#if defined(PSA_CRYPTO_IMPLEMENTED)
#include "crypto_struct_se.h"
#else
#include "crypto_struct_mbedtls.h"
#endif
