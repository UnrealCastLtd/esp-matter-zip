#if defined(PSA_CRYPTO_IMPLEMENTED)
#include "crypto_types_se.h"
#else
#include "crypto_types_mbedtls.h"
#endif
